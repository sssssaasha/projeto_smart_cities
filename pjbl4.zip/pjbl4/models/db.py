from flask_sqlalchemy import SQLAlchemy
    
db= SQLAlchemy()

instance = "mysql+pymysql://test1:test1@localhost:3306/projeto"